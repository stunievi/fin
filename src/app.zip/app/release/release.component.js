import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
var ReleaseComponent = /** @class */ (function () {
    function ReleaseComponent(router, activatedRoute) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.loginState = 0;
    }
    ReleaseComponent.prototype.ngOnInit = function () {
        if (this.loginState == 0) {
            // 未登录跳转登录页
            this.router.navigate(['/custom/login'], { relativeTo: this.activatedRoute });
        }
    };
    ReleaseComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-release',
                    templateUrl: './release.component.html',
                    styleUrls: ['./release.component.scss']
                },] },
    ];
    /** @nocollapse */
    ReleaseComponent.ctorParameters = function () { return [
        { type: Router, },
        { type: ActivatedRoute, },
    ]; };
    return ReleaseComponent;
}());
export { ReleaseComponent };
//# sourceMappingURL=release.component.js.map