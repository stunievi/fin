import { Component } from '@angular/core';
var FinFriendComponent = /** @class */ (function () {
    function FinFriendComponent() {
    }
    FinFriendComponent.prototype.ngOnInit = function () {
    };
    FinFriendComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-fin-friend',
                    templateUrl: './fin-friend.component.html',
                    styleUrls: ['./fin-friend.component.scss']
                },] },
    ];
    /** @nocollapse */
    FinFriendComponent.ctorParameters = function () { return []; };
    return FinFriendComponent;
}());
export { FinFriendComponent };
//# sourceMappingURL=fin-friend.component.js.map