import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
var RegisterComponent = /** @class */ (function () {
    function RegisterComponent(router, activatedRoute) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.pwdlen = 0;
        this.phonelen = 0;
        this.pwdType = 0;
    }
    RegisterComponent.prototype.ngOnInit = function () {
    };
    // 密码输入 不为空 出现删除按钮
    // 密码输入 不为空 出现删除按钮
    RegisterComponent.prototype.pwdInput = 
    // 密码输入 不为空 出现删除按钮
    function () {
        this.pwdlen = this.password.length;
    };
    RegisterComponent.prototype.phoneInput = function () {
        this.phonelen = this.phone.length;
    };
    // 切换密码可见/不可见
    // 切换密码可见/不可见
    RegisterComponent.prototype.pwdTypeToggle = 
    // 切换密码可见/不可见
    function () {
        this.pwdType == 0 ? this.pwdType = 1 : this.pwdType = 0;
    };
    // 取消
    // 取消
    RegisterComponent.prototype.back = 
    // 取消
    function () {
        // 这里判断id，url进来的带了一个关联id，比如你要查看一个用户的详细信息，根据id关联
        // 在这个页面获取到这个id，然后进行的路由的相对跳转
        this.router.navigate(['/index'], { relativeTo: this.activatedRoute });
    };
    RegisterComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-register',
                    templateUrl: './register.component.html',
                    styleUrls: ['./register.component.scss']
                },] },
    ];
    /** @nocollapse */
    RegisterComponent.ctorParameters = function () { return [
        { type: Router, },
        { type: ActivatedRoute, },
    ]; };
    return RegisterComponent;
}());
export { RegisterComponent };
//# sourceMappingURL=register.component.js.map