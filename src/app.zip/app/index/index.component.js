import { Component, ElementRef } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
var IndexComponent = /** @class */ (function () {
    function IndexComponent(media, router, el) {
        this.media = media;
        this.router = router;
        this.el = el;
        this.name = 'Fin.im';
        // 菜单选中
        this.linkChoice = '0';
        //  顶部导航按钮
        this.topNavButton = 0;
        this.medias = media;
        this.mobileQuery = this.medias.matchMedia('(max-width: 600px)');
        this.link = [
            { id: '0', title: '首页', icon: 'home', href: '/index' },
            { id: '1', title: 'F圈', icon: 'donut_large', href: '/index/finfriend' },
            { id: '2', title: '关注', icon: 'favorite', href: '/index/follow' },
            { id: '3', title: '精选', icon: 'thumb_up', href: '/index/choice' },
            { id: '4', title: '通知', icon: 'notifications', href: '/index/notification' },
        ];
        // icon
    }
    IndexComponent.prototype.ngAfterViewInit = function () {
        // 模板中的元素已创建完成
        // pc
        if (!this.mobileQuery.matches) {
            this.navdom = this.el.nativeElement.querySelector('#pc-nav');
            this.drawer = this.el.nativeElement.querySelector('#drawer');
            this.appContentWidth = this.el.nativeElement.querySelector('#app-content').clientWidth;
            this.navWidth = this.navdom.clientWidth;
            this.drawerWidth = this.drawer.clientWidth;
            this.appContentWidth = this.el.nativeElement.querySelector('#app-content').offsetWidth;
            this.navdom.style.width = this.appContentWidth + 'px';
        }
    };
    IndexComponent.prototype.ngOnInit = function () {
        var _this = this;
        // 页面监听 宽度变化
        Observable.fromEvent(window, 'resize')
            .debounceTime(100) // 以免频繁处理
            .subscribe(function (event) {
            // 这里处理页面变化时的操作
            // 这里处理页面变化时的操作
            _this.mobileQuery = _this.medias.matchMedia('(max-width: 600px)');
            if (!_this.mobileQuery.matches) {
                _this.navdom = _this.el.nativeElement.querySelector('#pc-nav');
                setTimeout(function () {
                    _this.appContentWidth = _this.el.nativeElement.querySelector('#app-content').offsetWidth;
                    _this.navdom.style.width = _this.appContentWidth + 'px';
                }, 100);
            }
        });
        this.router.events
            .subscribe(function (event) {
            // example: NavigationStart, RoutesRecognized, NavigationEnd
            // example: NavigationStart, RoutesRecognized, NavigationEnd
            _this.loginUi = event['url'];
        });
    };
    // 抽屉关闭
    // 抽屉关闭
    IndexComponent.prototype.sidenavclose = 
    // 抽屉关闭
    function () {
        var _this = this;
        // pc
        if (!this.mobileQuery.matches) {
            console.log(111);
            this.navWidth = this.navdom.clientWidth;
            setTimeout(function () {
                _this.appContentWidth = _this.el.nativeElement.querySelector('#app-content').offsetWidth;
                var _loop_1 = function (i) {
                    setTimeout(function () {
                        _this.navdom.style.width = i + 'px';
                    }, 5);
                };
                for (var i = _this.navWidth; i < _this.appContentWidth; i++) {
                    _loop_1(i);
                }
            }, 300);
            this.topNavButton = 1;
        }
    };
    // 抽屉打开
    // 抽屉打开
    IndexComponent.prototype.sidenavopen = 
    // 抽屉打开
    function () {
        var _this = this;
        if (!this.mobileQuery.matches && this.navdom.clientWidth != null) {
            this.navWidth = this.navdom.clientWidth;
            setTimeout(function () {
                _this.appContentWidth = _this.el.nativeElement.querySelector('#app-content').offsetWidth;
                var _loop_2 = function (i) {
                    setTimeout(function () {
                        _this.navdom.style.width = i + 'px';
                    }, 5);
                };
                for (var i = _this.navWidth; i > _this.appContentWidth; i--) {
                    _loop_2(i);
                }
            }, 300);
            this.topNavButton = 0;
        }
    };
    IndexComponent.prototype.choice = function (id) {
        this.linkChoice = id;
        console.log(id);
    };
    IndexComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-index',
                    templateUrl: './index.component.html',
                    styleUrls: ['./index.component.scss']
                },] },
    ];
    /** @nocollapse */
    IndexComponent.ctorParameters = function () { return [
        { type: MediaMatcher, },
        { type: Router, },
        { type: ElementRef, },
    ]; };
    return IndexComponent;
}());
export { IndexComponent };
//# sourceMappingURL=index.component.js.map