import { Component } from '@angular/core';
import { NzModalService } from 'ng-zorro-antd';
import { Router, ActivatedRoute } from '@angular/router';
var LoginComponent = /** @class */ (function () {
    function LoginComponent(modalService, router, activatedRoute) {
        this.modalService = modalService;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.pwdlen = 0;
    }
    LoginComponent.prototype.ngOnInit = function () {
    };
    // 密码输入 不为空 出现删除按钮
    // 密码输入 不为空 出现删除按钮
    LoginComponent.prototype.testInput = 
    // 密码输入 不为空 出现删除按钮
    function () {
        this.pwdlen = this.password.length;
    };
    // 删除按钮点击事件
    // 删除按钮点击事件
    LoginComponent.prototype.clearInput = 
    // 删除按钮点击事件
    function () {
        this.password = '';
        this.pwdlen = this.password.length;
    };
    // 取消
    // 取消
    LoginComponent.prototype.back = 
    // 取消
    function () {
        // 这里判断id，url进来的带了一个关联id，比如你要查看一个用户的详细信息，根据id关联
        // 在这个页面获取到这个id，然后进行的路由的相对跳转
        this.router.navigate(['/index'], { relativeTo: this.activatedRoute });
    };
    LoginComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-login',
                    templateUrl: './login.component.html',
                    styleUrls: ['./login.component.scss']
                },] },
    ];
    /** @nocollapse */
    LoginComponent.ctorParameters = function () { return [
        { type: NzModalService, },
        { type: Router, },
        { type: ActivatedRoute, },
    ]; };
    return LoginComponent;
}());
export { LoginComponent };
//# sourceMappingURL=login.component.js.map