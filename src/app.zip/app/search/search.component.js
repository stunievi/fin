import { Component } from '@angular/core';
var SearchComponent = /** @class */ (function () {
    function SearchComponent() {
    }
    SearchComponent.prototype.ngOnInit = function () {
    };
    SearchComponent.prototype.back = function () {
        window.history.go(-1);
    };
    SearchComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-search',
                    templateUrl: './search.component.html',
                    styleUrls: ['./search.component.scss']
                },] },
    ];
    /** @nocollapse */
    SearchComponent.ctorParameters = function () { return []; };
    return SearchComponent;
}());
export { SearchComponent };
//# sourceMappingURL=search.component.js.map