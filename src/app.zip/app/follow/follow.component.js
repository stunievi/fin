import { Component } from '@angular/core';
var FollowComponent = /** @class */ (function () {
    function FollowComponent() {
    }
    FollowComponent.prototype.ngOnInit = function () {
    };
    FollowComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-follow',
                    templateUrl: './follow.component.html',
                    styleUrls: ['./follow.component.scss']
                },] },
    ];
    /** @nocollapse */
    FollowComponent.ctorParameters = function () { return []; };
    return FollowComponent;
}());
export { FollowComponent };
//# sourceMappingURL=follow.component.js.map