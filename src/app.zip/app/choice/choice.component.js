import { Component } from '@angular/core';
var ChoiceComponent = /** @class */ (function () {
    function ChoiceComponent() {
        this.array = [1, 2, 3, 4];
    }
    ChoiceComponent.prototype.ngOnInit = function () {
    };
    ChoiceComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-choice',
                    templateUrl: './choice.component.html',
                    styleUrls: ['./choice.component.scss']
                },] },
    ];
    /** @nocollapse */
    ChoiceComponent.ctorParameters = function () { return []; };
    return ChoiceComponent;
}());
export { ChoiceComponent };
//# sourceMappingURL=choice.component.js.map