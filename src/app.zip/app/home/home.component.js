import { Component, ElementRef, } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
var HomeComponent = /** @class */ (function () {
    function HomeComponent(el, route) {
        this.el = el;
        this.route = route;
        this.infoList = ['1', '2', '3', '3', '3', '3', '3', '3', '3', '3', '3'];
        this.sele = el.nativeElement;
    }
    HomeComponent.prototype.ngOnInit = function () {
        // 页面监听
    };
    HomeComponent.prototype.release = function () {
        // ReleaseComponent
    };
    HomeComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-home',
                    templateUrl: './home.component.html',
                    styleUrls: ['./home.component.scss']
                },] },
    ];
    /** @nocollapse */
    HomeComponent.ctorParameters = function () { return [
        { type: ElementRef, },
        { type: ActivatedRoute, },
    ]; };
    return HomeComponent;
}());
export { HomeComponent };
//# sourceMappingURL=home.component.js.map