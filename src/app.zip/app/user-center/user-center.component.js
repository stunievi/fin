import { Component } from '@angular/core';
var UserCenterComponent = /** @class */ (function () {
    function UserCenterComponent() {
    }
    UserCenterComponent.prototype.ngOnInit = function () {
    };
    UserCenterComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-user-center',
                    templateUrl: './user-center.component.html',
                    styleUrls: ['./user-center.component.scss']
                },] },
    ];
    /** @nocollapse */
    UserCenterComponent.ctorParameters = function () { return []; };
    return UserCenterComponent;
}());
export { UserCenterComponent };
//# sourceMappingURL=user-center.component.js.map