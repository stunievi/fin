import { Component } from '@angular/core';
var NotificationComponent = /** @class */ (function () {
    function NotificationComponent() {
    }
    NotificationComponent.prototype.ngOnInit = function () {
    };
    NotificationComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-notification',
                    templateUrl: './notification.component.html',
                    styleUrls: ['./notification.component.scss']
                },] },
    ];
    /** @nocollapse */
    NotificationComponent.ctorParameters = function () { return []; };
    return NotificationComponent;
}());
export { NotificationComponent };
//# sourceMappingURL=notification.component.js.map