import { Component } from '@angular/core';
var ErrorComponent = /** @class */ (function () {
    function ErrorComponent() {
    }
    ErrorComponent.prototype.ngOnInit = function () {
    };
    ErrorComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-error',
                    templateUrl: './error.component.html',
                    styleUrls: ['./error.component.scss']
                },] },
    ];
    /** @nocollapse */
    ErrorComponent.ctorParameters = function () { return []; };
    return ErrorComponent;
}());
export { ErrorComponent };
//# sourceMappingURL=error.component.js.map