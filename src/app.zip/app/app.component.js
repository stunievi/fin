import { Component, ElementRef } from '@angular/core';
var AppComponent = /** @class */ (function () {
    function AppComponent(el) {
        this.el = el;
    }
    AppComponent.prototype.ngAfterViewInit = function () {
        // 模板中的元素已创建完成
    };
    AppComponent.prototype.ngOnInit = function () {
    };
    AppComponent.decorators = [
        { type: Component, args: [{
                    selector: 'app-fin',
                    templateUrl: './app.component.html',
                    styleUrls: ['./app.component.scss']
                },] },
    ];
    /** @nocollapse */
    AppComponent.ctorParameters = function () { return [
        { type: ElementRef, },
    ]; };
    return AppComponent;
}());
export { AppComponent };
//# sourceMappingURL=app.component.js.map