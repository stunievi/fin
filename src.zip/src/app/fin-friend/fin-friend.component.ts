import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fin-friend',
  templateUrl: './fin-friend.component.html',
  styleUrls: ['./fin-friend.component.scss']
})
export class FinFriendComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
